<?php

mail('kevin@kyroweb.com', 'Neighbors', 'The neighbors called again and said their printer got stuck. Do you think you could go over there in the morning and have a look at it? Thanks.', 'From: Karen Jacoby <karen.jacoby@gmail.com>');

?>