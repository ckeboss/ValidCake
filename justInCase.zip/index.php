<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
 "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd"> 
 
<html xmlns="http://www.w3.org/1999/xhtml"> 
	<head> 
		<title>Valid Cake - The Easiest Validation Generator for CakePHP Models</title> 
		<link href="style.css" rel="stylesheet" type="text/css" /> 
		<meta http-equiv="Author" content="Trevor Gau" /> 
		<meta http-equiv="Copyright" content="&copy; 2009 Trevor Gau" /> 
		<meta http-equiv="Content-Type" content="text/html;charset=utf-8" /> 
		<link rel="stylesheet" media="screen" href="reset.css" type="text/css" /> 
		<link rel="stylesheet" media="screen" href="style.css" type="text/css" /> 
		<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.3.2/jquery.js"></script> 
		<script type="text/javascript" src="application.js"></script>		
		<script type="text/javascript" src="tooltips.js"></script>	
	</head> 
	<body> 
		<div id="wrap"> 
			<div id="header"> 
				<div id="headerLeft"><h1 id="logo"><a href="index.php"><span>Valid Cake</span></a></h1> </div> 
				<div id="headerRight"> 
					<p><strong>Get started right away! Follow these simple instructions:</strong></p> 
					<ol> 
						<li>Add fields with the same names as your table's columns.</li> 
						<li>Add one or more rules to each field.</li> 
						<li>Customize your output.</li> 
						<li>Click Generate! Copy the results to your model.</li> 
					</ol> 
				</div> <!-- headerRight --> 
			</div> <!-- header --> 
			<p id="noobs">
				<a class="hide" href="#">[Hide]</a>New to CakePHP Validation? No problem! Just go over to the Cookbook and read up on <a href="http://book.cakephp.org/view/125/Data-Validation" rel="external">Data Validation</a>. Valid Cake uses the "<a href="http://book.cakephp.org/view/133/Multiple-Rules-per-Field" rel="external">Multiple Rules per Field</a>" method. 
			</p>
			<form action="" method="post" id="form"> 
				<fieldset id="fieldset"> 
				
					<div id="fields"></div> 
					
					<p><a href="#" id="addField"><span>Add Field</span></a></p> 
					
					<p> 
						<label for="numTabs"> 
							Number of Tabs <a href="#" id="numTabsAnchor">[?]</a> 
						</label> 
						<select id="numTabs" name="options[num_tabs]">
							<option value="0">Zero</option>
							<option value="1" selected="selected">One</option>
							<option value="2">Two</option>
							<option value="3">Three</option>
						</select>
						<!-- <input type="text" id="numTabs" name="options[num_tabs]" />  -->
					</p> 
					
					<p> 
						<input type="checkbox" id="extraOptions" name="options[extra_options]" /> 
						<label for="extraOptions"> 
							Include default options? <a href="#" id="defaultOptionsAnchor">[?]</a> 
						</label> 
					</p> 
					
					<p><input name="submit" type="submit" value="Generate!" id="submit" /><div id="ajaxWorking"></div></p> 
				</fieldset>		
			</form> 
			
			<div id="results">Your $validate array will appear here...</div> 
		</div> <!-- wrap --> 
		<span id="footer">&copy; 2009 <a href="http://trevorsg.com">Trevor Gau</a>. Design by <a href="http://kevinjj.com">Kevin Jacoby</a>.</span> 
		<div id="tips"></div>
	</body> 
</html> 
 